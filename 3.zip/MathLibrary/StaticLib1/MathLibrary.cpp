#include <iostream>
#include "MathLibrary.h"
using namespace std;
int perimeter(int a, int b, int c)
{
	return a + b + c;
}
int plot(int a, int height)
{
	return (a + height) / 2;
}
