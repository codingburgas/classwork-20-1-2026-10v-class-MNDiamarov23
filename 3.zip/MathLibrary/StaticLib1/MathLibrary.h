#pragma once
int perimeter(int, int, int);
int plot(int ,int);
